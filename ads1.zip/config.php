<?php
include ('dbConfig.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Configurações - NewBank</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Configurações da Conta</h1>
    <p>Aqui você pode alterar sua senha ou e-mail. (Simulado)</p>
    <a href="painel.php">← Voltar ao Painel</a>
</body>
</html>
